<!DOCTYPE html>
<html lang="en">
<head>
    <title>EMC</title>
</head>
<body>
    <?php
    include("include/header.php")
    ?>
</body>
</html>