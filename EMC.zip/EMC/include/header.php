<!DOCTYPE html>
<html lang="en">
<head>
    <title>EMC</title>

    <link rel="stylesheet" href="/css/style.css">
    
</head>
<body>
    <nav class="navbar.da">

    <h5 class="text-white">EMC Mobile System</h5>

        <ul class="navbar">
        <li class="nav"><a href="login.php">Admin</a></li>
            <li class="nav"><a href="#">Smartphones</a></li>
            <li class="nav"><a href="#">Accessories</a></li>
            <li class="nav"><a href="#">Branches</a></li>
        </ul>
    </nav>




</body>
</html>